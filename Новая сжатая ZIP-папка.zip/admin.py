from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.filters import Command, Filter
from config import ADMIN_IDS
from core.database import db
from keyboards.admin_kb import admin_main_kb  #старі кнопки
from aiogram.fsm.context import FSMContext
from states.admin_states import AdminState
from keyboards.reply import main_menu # Для виходу в клієнтське меню
from keyboards.admin_kb import admin_main_kb, services_management_kb # Для керування послугами
from keyboards.admin_kb import reminder_dates_kb

router = Router()


class IsAdmin(Filter):
    async def __call__(self, msg: Message) -> bool:
        return msg.from_user.id in ADMIN_IDS


@router.message(Command("admin"), IsAdmin())
async def admin_start(message: Message):
    await message.answer("Адмін-панель v2.0", reply_markup=admin_main_kb())


# --- ПЕРЕГЛЯД ВСІХ ЗАПИСІВ
@router.message(F.text == "📋 Всі записи", IsAdmin())
async def view_all(message: Message):
    apps = await db.get_all_appointments()
    if not apps:
        await message.answer("Записів немає.")
        return

    for app in apps:
        # app: id, name, phone, service, master, date, time, username, is_confirmed
        status_icon = "✅" if app[8] else "⏳"
        text = (
            f"{status_icon} <b>Запис #{app[0]}</b>\n"
            f"👤 {app[1]} ({app[2]})\n"
            f"✂️ {app[3]} | 💈 {app[4]}\n"
            f"📅 {app[5]} {app[6]}"
        )

        kb = InlineKeyboardBuilder()
        if not app[8]:  # if не підтверджено - показати кнопку
            kb.button(text="✅ Підтвердити", callback_data=f"adm_confirm_{app[0]}")
        kb.button(text="❌ Скасувати", callback_data=f"adm_cancel_{app[0]}")

        await message.answer(text, reply_markup=kb.as_markup(), parse_mode="HTML")


@router.callback_query(F.data.startswith("adm_confirm_"))
async def confirm_app(callback: CallbackQuery):
    app_id = callback.data.split("_")[2]
    await db.confirm_appointment(app_id)
    await callback.message.edit_text(f"✅ Запис #{app_id} ПІДТВЕРДЖЕНО! Клієнт отримає нагадування.")



@router.message(F.text == "👥 Графік майстрів (Beta)", IsAdmin())
async def master_schedule_start(message: Message):
    masters = await db.get_masters()
    kb = InlineKeyboardBuilder()
    for m in masters:
        kb.button(text=m[1], callback_data=f"sched_master_{m[0]}")
    await message.answer("Оберіть майстра:", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("sched_master_"))
async def show_master_schedule(callback: CallbackQuery):
    master_id = callback.data.split("_")[2]
    apps = await db.get_appointments_by_master(master_id)

    if not apps:
        await callback.message.edit_text("У цього майстра поки порожньо.")
        return

    text = f"📅 <b>Графік майстра:</b>\n\n"
    for app in apps:
        text += f"🕒 {app[4]} {app[5]} - {app[3]} ({app[1]})\n"

    await callback.message.edit_text(text, parse_mode="HTML")

    @router.message(F.text == "🚪 Вийти", IsAdmin())
    async def admin_exit(message: Message):
        await message.answer("Ви повернулися в режим клієнта.", reply_markup=main_menu())


    @router.message(F.text == "✂️ Керування послугами", IsAdmin())
    async def manage_services(message: Message):
        services = await db.get_services()
        await message.answer(
            "Оберіть дію або послугу для видалення:",
            reply_markup=services_management_kb(services)
        )


    @router.callback_query(F.data.startswith("del_serv_"))
    async def delete_service_handler(callback: CallbackQuery):
        service_id = callback.data.split("_")[2]
        await db.delete_service(service_id)


        services = await db.get_services()
        await callback.message.edit_text(
            "✅ Послугу видалено. Оберіть дію:",
            reply_markup=services_management_kb(services)
        )


    @router.callback_query(F.data == "add_service")
    async def start_add_service(callback: CallbackQuery, state: FSMContext):
        await callback.message.answer("Введіть НАЗВУ нової послуги (наприклад: Дитяча стрижка):")
        await state.set_state(AdminState.add_service_name)
        await callback.answer()

    @router.message(AdminState.add_service_name)
    async def add_service_name(message: Message, state: FSMContext):
        await state.update_data(name=message.text)
        await message.answer("Введіть ЦІНУ (тільки цифри, наприклад: 300):")
        await state.set_state(AdminState.add_service_price)

    @router.message(AdminState.add_service_price)
    async def add_service_price(message: Message, state: FSMContext):
        try:
            price = float(message.text)
            await state.update_data(price=price)
            await message.answer("Введіть ТРИВАЛІСТЬ у хвилинах (тільки цифри, наприклад: 45):")
            await state.set_state(AdminState.add_service_duration)
        except ValueError:
            await message.answer("⚠️ Будь ласка, введіть число (без літер і пробілів).")

    @router.message(AdminState.add_service_duration)
    async def add_service_finish(message: Message, state: FSMContext):
        try:
            duration = int(message.text)
            data = await state.get_data()


            await db.add_service(data['name'], data['price'], duration)

            await message.answer(
                f"✅ Послуга '{data['name']}' успішно додана в меню!",
                reply_markup=admin_main_kb()
            )
            await state.clear()
        except ValueError:
            await message.answer("⚠️ Введіть ціле число хвилин.")


@router.message(F.text == "🔔 Нагадування", IsAdmin())
async def manual_reminders_menu(message: Message):

    dates = await db.get_dates_for_reminders()

    if not dates:
        await message.answer("✅ Немає підтверджених записів, які потребують нагадування.")
        return

    await message.answer(
        "Оберіть дату, на яку хочете розіслати нагадування клієнтам:",
        reply_markup=reminder_dates_kb(dates)
    )


@router.callback_query(F.data.startswith("remind_date_"))
async def send_reminders_for_date(callback: CallbackQuery):
    date = callback.data.split("_")[2]  # беремо дату з callback_data

    # отримуємо список клієнтів на цю дату
    appointments = await db.get_appointments_for_reminder_by_date(date)

    if not appointments:
        await callback.message.edit_text(f"На {date} немає кому відправляти нагадування.")
        return

    success_count = 0
    await callback.message.edit_text(f"⏳ Розпочинаю розсилку на {date}...")

    # проходимося по кожному клієнту і відправляємо повідомлення
    for app in appointments:
        app_id, user_id, service_name, app_time = app

        text = (
            f"🔔 <b>Нагадування про візит!</b>\n\n"
            f"Чекаємо на вас <b>{date}</b> о <b>{app_time}</b>.\n"
            f"Послуга: {service_name}\n\n"
            f"<i>До зустрічі у KremenBarber!</i>"
        )

        try:
            # відправляємо повідомлення від імені бота
            await callback.bot.send_message(chat_id=user_id, text=text, parse_mode="HTML")
            # відмічаємо в базі, що нагадування відправлено
            await db.mark_reminder_sent(app_id)
            success_count += 1
        except Exception as e:
            print(f"Помилка відправки користувачу {user_id}: {e}")

    await callback.message.answer(f"✅ Розсилка на {date} завершена!\nУспішно відправлено: {success_count} шт.")
    await callback.answer()